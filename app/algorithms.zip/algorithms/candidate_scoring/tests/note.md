python -m fpg_core.candidate_scoring.tests.debug

pytest -q app/algorithms/candidate_scoring/tests